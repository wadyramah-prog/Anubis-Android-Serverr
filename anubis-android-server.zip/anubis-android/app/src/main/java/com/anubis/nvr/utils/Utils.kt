package com.anubis.nvr.utils

// ============================================================
//  👁️  Eye of Anubis Android — Config + Utils
// ============================================================

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import com.anubis.nvr.camera.CameraConfig
import com.anubis.nvr.camera.CameraSource

// ─── DataStore ────────────────────────────────────────────────

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "anubis_config")

// ─── NVR Config ───────────────────────────────────────────────

data class NvrConfig(
    val nodeName:       String         = "Anubis-Android",
    val ownerName:      String         = "Eye of Anubis User",
    val webPort:        Int            = 8080,
    val apiPort:        Int            = 8081,
    val maxCameras:     Int            = 4,
    val retentionDays:  Int            = 7,
    val aiEnabled:      Boolean        = true,
    val cameras:        List<CameraConfig> = emptyList(),
    val safStorageUri:  String?        = null,
    val telegramToken:  String?        = null,
    val telegramChatId: String?        = null,
    val startOnBoot:    Boolean        = true,
    val motionThreshold: Float         = 0.05f,
    val loiteringSecs:  Int            = 30,
) {
    companion object {
        fun load(context: Context): NvrConfig {
            return runBlocking {
                val prefs = context.dataStore.data.first()
                NvrConfig(
                    nodeName      = prefs[stringPreferencesKey("node_name")]   ?: "Anubis-Android",
                    ownerName     = prefs[stringPreferencesKey("owner_name")]  ?: "Eye of Anubis User",
                    webPort       = prefs[intPreferencesKey("web_port")]       ?: 8080,
                    maxCameras    = prefs[intPreferencesKey("max_cameras")]    ?: getMaxCameras(context),
                    retentionDays = prefs[intPreferencesKey("retention_days")] ?: 7,
                    aiEnabled     = prefs[booleanPreferencesKey("ai_enabled")] ?: true,
                    safStorageUri = prefs[stringPreferencesKey("saf_uri")],
                    telegramToken = prefs[stringPreferencesKey("tg_token")],
                    startOnBoot   = prefs[booleanPreferencesKey("start_boot")] ?: true,
                    cameras       = loadCameras(prefs),
                )
            }
        }

        private fun getMaxCameras(context: Context): Int {
            val mi = android.app.ActivityManager.MemoryInfo()
            (context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager)
                .getMemoryInfo(mi)
            val totalMb = mi.totalMem / 1_048_576
            return when {
                totalMb >= 8192 -> 8
                totalMb >= 4096 -> 4
                else            -> 2
            }
        }

        private fun loadCameras(prefs: Preferences): List<CameraConfig> {
            val json = prefs[stringPreferencesKey("cameras_json")] ?: return emptyList()
            return try {
                val arr = org.json.JSONArray(json)
                (0 until arr.length()).map { i ->
                    val obj = arr.getJSONObject(i)
                    CameraConfig(
                        id       = obj.getString("id"),
                        name     = obj.getString("name"),
                        rtspUrl  = obj.optString("rtsp_url"),
                        username = obj.optString("username"),
                        password = obj.optString("password"),
                        width    = obj.optInt("width", 1280),
                        height   = obj.optInt("height", 720),
                        fps      = obj.optInt("fps", 15),
                        source   = if (obj.optString("source") == "phone")
                            CameraSource.PHONE else CameraSource.RTSP,
                    )
                }
            } catch (e: Exception) {
                Log.e("NvrConfig", "Failed to load cameras: ${e.message}")
                emptyList()
            }
        }
    }
}

// ─── Network Utils ────────────────────────────────────────────

object NetworkUtils {
    fun getLocalIpAddress(context: Context): String? {
        return try {
            val wm = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            if (ip == 0) {
                // Try via NetworkInterface
                java.net.NetworkInterface.getNetworkInterfaces()
                    ?.asSequence()
                    ?.flatMap { it.inetAddresses.asSequence() }
                    ?.firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address }
                    ?.hostAddress
            } else {
                // Convert int IP to string
                "%d.%d.%d.%d".format(
                    ip and 0xFF,
                    (ip shr 8)  and 0xFF,
                    (ip shr 16) and 0xFF,
                    (ip shr 24) and 0xFF,
                )
            }
        } catch (e: Exception) {
            Log.e("NetworkUtils", "Failed to get IP: ${e.message}")
            null
        }
    }
}

// ─── Boot Receiver ────────────────────────────────────────────

package com.anubis.nvr.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.anubis.nvr.utils.NvrConfig

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val config = NvrConfig.load(context)
            if (config.startOnBoot) {
                Log.i("AnubisBoot", "Auto-starting NVR Server on boot")
                NvrServerService.start(context)
            }
        }
    }
}

// ─── Application Class ────────────────────────────────────────

package com.anubis.nvr

import android.app.Application
import android.util.Log

class AnubisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("AnubisApp", "👁️ Eye of Anubis Android NVR v1.0.0 starting")

        // Initialize crash reporting in production
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("AnubisApp", "CRASH in ${thread.name}: ${throwable.message}", throwable)
        }
    }
}
