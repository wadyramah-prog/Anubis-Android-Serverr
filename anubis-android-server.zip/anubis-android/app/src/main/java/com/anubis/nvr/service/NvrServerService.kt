package com.anubis.nvr.service

// ============================================================
//  👁️  Eye of Anubis Android — NVR Server Service
//  service/NvrServerService.kt
//
//  THIS IS THE HEART OF THE ANDROID NVR.
//
//  Runs as a Foreground Service — stays alive when:
//    - Screen is off ✅
//    - App is swiped away ✅
//    - Phone sleeps ✅ (with WakeLock)
//    - On boot ✅ (via BootReceiver)
//
//  MANAGES:
//    1. RTSP camera ingestion (via ExoPlayer + FFmpeg-Kit)
//    2. H.265 encoding (Android MediaCodec hardware encoder)
//    3. Storage writing (Internal / SD Card / USB OTG / Cloud)
//    4. AI detection (TFLite YOLOv10-nano)
//    5. Web UI HTTP server (NanoHTTPD on port 8080)
//    6. Notification with live stats
// ============================================================

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.anubis.nvr.R
import com.anubis.nvr.camera.CameraManager
import com.anubis.nvr.storage.StorageManager
import com.anubis.nvr.ai.AiEngine
import com.anubis.nvr.utils.NvrConfig
import com.anubis.nvr.utils.NetworkUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class NvrServerService : Service() {

    companion object {
        const val CHANNEL_ID         = "anubis_nvr_server"
        const val NOTIFICATION_ID    = 1001
        const val ACTION_START       = "com.anubis.nvr.START"
        const val ACTION_STOP        = "com.anubis.nvr.STOP"
        const val ACTION_ADD_CAMERA  = "com.anubis.nvr.ADD_CAMERA"

        // Shared state (observable by UI)
        val serverState = MutableStateFlow(NvrServerState())

        fun start(context: Context) {
            val intent = Intent(context, NvrServerService::class.java)
                .setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, NvrServerService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    // ── Core components ────────────────────────────────────────
    private lateinit var cameraManager:  CameraManager
    private lateinit var storageManager: StorageManager
    private lateinit var aiEngine:       AiEngine
    private lateinit var webServer:      NvrWebServer
    private lateinit var config:         NvrConfig

    // ── Android power management ───────────────────────────────
    private lateinit var wakeLock:       PowerManager.WakeLock
    private lateinit var wifiLock:       WifiManager.WifiLock

    // ── Coroutines ────────────────────────────────────────────
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ─── Lifecycle ────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()

        // Load config
        config = NvrConfig.load(this)

        // Initialize components
        cameraManager  = CameraManager(this, config, serviceScope)
        storageManager = StorageManager(this, config)
        aiEngine       = AiEngine(this, config)
        webServer      = NvrWebServer(this, config, cameraManager, storageManager, aiEngine)

        // Power management
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AnubisNVR::RecordingWakeLock"
        )

        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "AnubisNVR::WiFiLock")

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startNvr()
            ACTION_STOP  -> stopNvr()
        }
        return START_STICKY  // Restart if killed by OS
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopNvr()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ─── Start NVR ────────────────────────────────────────────

    private fun startNvr() {
        // Acquire power locks
        if (!wakeLock.isHeld) wakeLock.acquire()
        if (!wifiLock.isHeld) wifiLock.acquire()

        // Start as foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification("Starting..."),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification("Starting..."))
        }

        serviceScope.launch {
            try {
                // 1. Initialize storage
                storageManager.init()

                // 2. Start AI engine (loads TFLite model)
                aiEngine.init()

                // 3. Start Web Server (serves UI + API on port 8080)
                webServer.start(config.webPort)
                val ip = NetworkUtils.getLocalIpAddress(this@NvrServerService)
                android.util.Log.i("AnubisNVR", "Web UI: http://$ip:${config.webPort}")

                // 4. Start configured cameras
                config.cameras.forEach { camConfig ->
                    cameraManager.addCamera(camConfig)
                }

                // 5. Update state
                serverState.value = NvrServerState(
                    running        = true,
                    serverIp       = ip ?: "unknown",
                    webPort        = config.webPort,
                    camerasTotal   = config.cameras.size,
                    camerasOnline  = 0,
                )

                // 6. Start stats update loop
                startStatsLoop()

            } catch (e: Exception) {
                android.util.Log.e("AnubisNVR", "Failed to start NVR: ${e.message}", e)
                updateNotification("Error: ${e.message}")
            }
        }
    }

    private fun stopNvr() {
        serviceScope.launch {
            cameraManager.stopAll()
            webServer.stop()
            storageManager.flushAll()
            aiEngine.close()
        }

        if (wakeLock.isHeld) wakeLock.release()
        if (wifiLock.isHeld) wifiLock.release()

        serverState.value = NvrServerState(running = false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ─── Stats Loop ───────────────────────────────────────────

    private fun startStatsLoop() {
        serviceScope.launch {
            while (isActive) {
                val state = serverState.value
                val cameras = cameraManager.getCameraStatuses()
                val onlineCams = cameras.count { it.connected }
                val storagePct = storageManager.getUsagePct()

                val newState = state.copy(
                    camerasOnline  = onlineCams,
                    storageUsedPct = storagePct,
                    eventsToday    = aiEngine.getEventCount(),
                    uptime         = state.uptime + 5,
                )
                serverState.value = newState

                updateNotification(
                    "📷 $onlineCams/${state.camerasTotal} cameras · " +
                    "💾 ${storagePct.toInt()}% · " +
                    "http://${state.serverIp}:${state.webPort}"
                )

                delay(5000)
            }
        }
    }

    // ─── Notification ─────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Anubis NVR Server",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Eye of Anubis NVR recording service"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, com.anubis.nvr.ui.MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, NvrServerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("👁️ عين أنوبيس — NVR Server")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_eye_notification)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, "Stop", stopIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification(status: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(status))
    }
}

// ─── Server State ─────────────────────────────────────────────

data class NvrServerState(
    val running:        Boolean = false,
    val serverIp:       String  = "",
    val webPort:        Int     = 8080,
    val camerasTotal:   Int     = 0,
    val camerasOnline:  Int     = 0,
    val storageUsedPct: Float   = 0f,
    val eventsToday:    Int     = 0,
    val uptime:         Long    = 0L,
    val recordingActive: Boolean = false,
)
