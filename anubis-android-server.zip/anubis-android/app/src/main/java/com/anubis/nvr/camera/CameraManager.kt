package com.anubis.nvr.camera

// ============================================================
//  👁️  Eye of Anubis Android — Camera Manager
//  camera/CameraManager.kt
//
//  SUPPORTS TWO CAMERA MODES:
//
//  1. RTSP NETWORK CAMERAS (IP cameras)
//     Uses ExoPlayer's built-in RTSP support for pulling
//     streams, then pipes to MediaCodec for re-encoding.
//     Max: 4-8 cameras depending on Android device.
//
//  2. PHONE CAMERA AS SOURCE
//     Uses Camera2 API to capture from the phone's own
//     camera (front or back) and stream it as RTSP or
//     save directly. Perfect for mobile surveillance.
//
//  ENCODING:
//     Uses Android MediaCodec (hardware H.265 encoder).
//     All major Android devices since 2017 support
//     hardware H.265 encoding — zero CPU cost.
//
//  ANDROID LIMITS:
//     - RAM: Each RTSP stream needs ~50-150MB RAM
//     - CPU: Motion detection in Java, AI via TFLite GPU
//     - Thermal: Android throttles CPU at ~85°C
// ============================================================

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.util.Size
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.common.MediaItem
import com.anubis.nvr.utils.NvrConfig
import com.anubis.nvr.storage.StorageManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import android.util.Log

class CameraManager(
    private val context:  Context,
    private val config:   NvrConfig,
    private val scope:    CoroutineScope,
) {
    companion object {
        private const val TAG = "AnubisCamManager"

        // Hardware H.265 limits on Android
        const val MAX_CAMERAS_LOW_END   = 2   // 2GB RAM phones
        const val MAX_CAMERAS_MID_RANGE = 4   // 4-6GB RAM phones
        const val MAX_CAMERAS_HIGH_END  = 8   // 8GB+ RAM phones
    }

    private val cameras = mutableMapOf<String, CameraChannel>()
    private val _statuses = MutableStateFlow<List<CameraStatus>>(emptyList())
    val statuses: StateFlow<List<CameraStatus>> = _statuses

    // ─── Add Camera ───────────────────────────────────────────

    fun addCamera(camConfig: CameraConfig): CameraChannel {
        if (cameras.size >= getMaxCameras()) {
            throw Exception("Max cameras reached (${getMaxCameras()}) for this device")
        }

        val channel = when (camConfig.source) {
            CameraSource.RTSP   -> RtspCameraChannel(context, camConfig, scope)
            CameraSource.PHONE  -> PhoneCameraChannel(context, camConfig, scope)
        }

        cameras[camConfig.id] = channel
        channel.start()

        Log.i(TAG, "Camera added: ${camConfig.name} (${camConfig.source})")
        updateStatuses()
        return channel
    }

    fun removeCamera(cameraId: String) {
        cameras[cameraId]?.stop()
        cameras.remove(cameraId)
        updateStatuses()
    }

    fun stopAll() {
        cameras.values.forEach { it.stop() }
        cameras.clear()
    }

    fun getCameraStatuses() = cameras.values.map { it.status }

    fun getCamera(id: String) = cameras[id]

    private fun updateStatuses() {
        _statuses.value = cameras.values.map { it.status }
    }

    private fun getMaxCameras(): Int {
        val runtime = Runtime.getRuntime()
        val maxMem  = runtime.maxMemory() / 1_048_576  // MB
        return when {
            maxMem >= 8192 -> MAX_CAMERAS_HIGH_END
            maxMem >= 4096 -> MAX_CAMERAS_MID_RANGE
            else           -> MAX_CAMERAS_LOW_END
        }
    }
}

// ─── Camera Source Types ──────────────────────────────────────

enum class CameraSource { RTSP, PHONE }

data class CameraConfig(
    val id:         String,
    val name:       String,
    val source:     CameraSource = CameraSource.RTSP,
    val rtspUrl:    String       = "",
    val username:   String       = "",
    val password:   String       = "",
    val width:      Int          = 1280,
    val height:     Int          = 720,
    val fps:        Int          = 15,
    val priority:   String       = "normal",
    val aiEnabled:  Boolean      = false,
    val phoneCamera: String      = "back",  // "front" or "back"
)

data class CameraStatus(
    val id:           String,
    val name:         String,
    val connected:    Boolean = false,
    val recording:    Boolean = false,
    val motionActive: Boolean = false,
    val fpsCurrent:   Int     = 0,
    val bitrateKbps:  Int     = 0,
    val framesTotal:  Long    = 0L,
    val reconnects:   Int     = 0,
)

// ─── Base Camera Channel ──────────────────────────────────────

abstract class CameraChannel(
    protected val config: CameraConfig,
    protected val scope:  CoroutineScope,
) {
    protected var _status = CameraStatus(
        id   = config.id,
        name = config.name,
    )
    val status: CameraStatus get() = _status

    // Frame callback for AI + motion detection
    var onFrameAvailable: ((ByteArray, Int, Int) -> Unit)? = null

    abstract fun start()
    abstract fun stop()
    abstract fun isConnected(): Boolean
}

// ─── RTSP Camera Channel ──────────────────────────────────────
// Pulls RTSP stream from IP camera using ExoPlayer

class RtspCameraChannel(
    private val context: Context,
    config:              CameraConfig,
    scope:               CoroutineScope,
) : CameraChannel(config, scope) {

    private var player:         ExoPlayer?         = null
    private var encoder:        H265Encoder?       = null
    private var reconnectJob:   Job?               = null
    private var reconnectCount  = 0
    private var framesReceived  = 0L

    override fun start() {
        scope.launch(Dispatchers.Main) {
            initPlayer()
        }
    }

    private fun initPlayer() {
        // Build authenticated RTSP URL
        val rtspUrl = buildAuthUrl()

        // Create ExoPlayer with RTSP source
        player = ExoPlayer.Builder(context).build().apply {
            val mediaItem   = MediaItem.fromUri(rtspUrl)
            val mediaSource = RtspMediaSource.Factory()
                .setDebugLoggingEnabled(false)
                .createMediaSource(mediaItem)

            setMediaSource(mediaSource)
            prepare()
            playWhenReady = true

            addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        androidx.media3.common.Player.STATE_READY -> {
                            _status = _status.copy(connected = true, recording = true)
                            Log.i("AnubisRTSP", "Connected: ${config.name}")
                            startEncoder()
                        }
                        androidx.media3.common.Player.STATE_IDLE,
                        androidx.media3.common.Player.STATE_ENDED -> {
                            _status = _status.copy(connected = false, recording = false)
                            scheduleReconnect()
                        }
                        else -> {}
                    }
                }

                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Log.e("AnubisRTSP", "Error: ${error.message}")
                    _status = _status.copy(connected = false)
                    scheduleReconnect()
                }
            })
        }
    }

    private fun startEncoder() {
        encoder = H265Encoder(
            width   = config.width,
            height  = config.height,
            fps     = config.fps,
            bitrate = calculateBitrate(config.width, config.height, config.fps),
        )
        encoder?.start()
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            val delayMs = minOf(500L * (1 shl reconnectCount), 30_000L)
            Log.d("AnubisRTSP", "Reconnecting in ${delayMs}ms...")
            delay(delayMs)
            reconnectCount++
            _status = _status.copy(reconnects = reconnectCount)
            withContext(Dispatchers.Main) { initPlayer() }
        }
    }

    override fun stop() {
        reconnectJob?.cancel()
        encoder?.stop()
        scope.launch(Dispatchers.Main) {
            player?.release()
            player = null
        }
        _status = _status.copy(connected = false, recording = false)
    }

    override fun isConnected() = _status.connected

    private fun buildAuthUrl(): String {
        val url = config.rtspUrl
        if (config.username.isEmpty()) return url
        return if (url.startsWith("rtsp://")) {
            "rtsp://${config.username}:${config.password}@${url.removePrefix("rtsp://")}"
        } else url
    }

    private fun calculateBitrate(w: Int, h: Int, fps: Int): Int {
        // H.265: ~60% of H.264 at same quality
        // Target: 1080p@25fps = 2Mbps, 720p@15fps = 800Kbps
        val pixels = w * h
        return when {
            pixels >= 1920 * 1080 -> 2_000_000
            pixels >= 1280 * 720  -> 800_000
            pixels >= 640 * 480   -> 300_000
            else                  -> 150_000
        }
    }
}

// ─── Phone Camera Channel ─────────────────────────────────────
// Uses the phone's own camera as a source (Camera2 API)

class PhoneCameraChannel(
    private val context: Context,
    config:              CameraConfig,
    scope:               CoroutineScope,
) : CameraChannel(config, scope) {

    private var cameraCapture: CameraCapture? = null

    override fun start() {
        scope.launch {
            try {
                cameraCapture = CameraCapture(
                    context     = context,
                    lensFacing  = if (config.phoneCamera == "front")
                        android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT
                        else android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK,
                    size        = Size(config.width, config.height),
                    fps         = config.fps,
                )
                cameraCapture?.start { yuv, w, h ->
                    // Frame available — send to AI + encoder
                    onFrameAvailable?.invoke(yuv, w, h)
                    _status = _status.copy(
                        connected  = true,
                        recording  = true,
                        framesTotal = _status.framesTotal + 1,
                    )
                }
                _status = _status.copy(connected = true)
            } catch (e: Exception) {
                Log.e("AnubisPhone", "Phone camera error: ${e.message}")
                _status = _status.copy(connected = false)
            }
        }
    }

    override fun stop() {
        cameraCapture?.stop()
        _status = _status.copy(connected = false, recording = false)
    }

    override fun isConnected() = _status.connected
}

// ─── H.265 Hardware Encoder (MediaCodec) ─────────────────────

class H265Encoder(
    private val width:   Int,
    private val height:  Int,
    private val fps:     Int,
    private val bitrate: Int,
) {
    private var codec: MediaCodec? = null

    fun start() {
        val format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_HEVC, width, height
        ).apply {
            setInteger(MediaFormat.KEY_BIT_RATE,              bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE,            fps)
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,      2)     // Keyframe every 2s
            setInteger(MediaFormat.KEY_COMPLEXITY,
                MediaCodecInfo.EncoderCapabilities.COMPLEXITY_HIGH)
            // Enable hardware acceleration
            setInteger("vendor.qti-ext-enc-low-latency.enable", 1)   // Qualcomm
        }

        try {
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_HEVC)
            codec?.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec?.start()
            Log.i("AnubisH265", "H.265 hardware encoder started: ${width}x${height}@${fps}fps")
        } catch (e: Exception) {
            Log.e("AnubisH265", "H.265 encoder failed, falling back to H.264: ${e.message}")
            startH264Fallback(format)
        }
    }

    private fun startH264Fallback(format: MediaFormat) {
        val h264Format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_AVC, width, height
        ).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, (bitrate * 1.6).toInt())  // H.264 needs more
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec?.configure(h264Format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec?.start()
    }

    fun stop() {
        try {
            codec?.stop()
            codec?.release()
            codec = null
        } catch (_: Exception) {}
    }
}

// ─── Camera2 Capture ─────────────────────────────────────────
// Captures from phone camera, outputs YUV frames

class CameraCapture(
    private val context:    Context,
    private val lensFacing: Int,
    private val size:       Size,
    private val fps:        Int,
) {
    private var captureSession: android.hardware.camera2.CameraCaptureSession? = null
    private var cameraDevice:   android.hardware.camera2.CameraDevice?         = null

    fun start(onFrame: (ByteArray, Int, Int) -> Unit) {
        val manager = context.getSystemService(Context.CAMERA_SERVICE)
            as android.hardware.camera2.CameraManager

        // Find camera with the requested facing
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id)
                .get(android.hardware.camera2.CameraCharacteristics.LENS_FACING) == lensFacing
        } ?: throw Exception("Camera not found")

        // Open camera (requires permission check in Activity)
        manager.openCamera(cameraId, object :
            android.hardware.camera2.CameraDevice.StateCallback() {
            override fun onOpened(camera: android.hardware.camera2.CameraDevice) {
                cameraDevice = camera
                startCapture(camera, onFrame)
            }
            override fun onDisconnected(camera: android.hardware.camera2.CameraDevice) {
                camera.close()
            }
            override fun onError(camera: android.hardware.camera2.CameraDevice, error: Int) {
                camera.close()
            }
        }, null)
    }

    private fun startCapture(
        camera:  android.hardware.camera2.CameraDevice,
        onFrame: (ByteArray, Int, Int) -> Unit
    ) {
        // Set up ImageReader to receive YUV_420_888 frames
        val reader = android.media.ImageReader.newInstance(
            size.width, size.height,
            android.graphics.ImageFormat.YUV_420_888,
            3  // Buffer 3 frames
        )

        reader.setOnImageAvailableListener({ imageReader ->
            val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                // Convert YUV planes to byte array
                val yPlane = image.planes[0]
                val yuv    = yPlane.buffer.let { buf ->
                    ByteArray(buf.remaining()).also { buf.get(it) }
                }
                onFrame(yuv, image.width, image.height)
            } finally {
                image.close()
            }
        }, null)

        // Create capture session
        val surfaces = listOf(reader.surface)
        camera.createCaptureSession(surfaces,
            object : android.hardware.camera2.CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: android.hardware.camera2.CameraCaptureSession) {
                    captureSession = session
                    val request = camera.createCaptureRequest(
                        android.hardware.camera2.CameraDevice.TEMPLATE_PREVIEW
                    ).apply {
                        addTarget(reader.surface)
                        set(android.hardware.camera2.CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                            android.util.Range(fps, fps))
                    }.build()
                    session.setRepeatingRequest(request, null, null)
                }
                override fun onConfigureFailed(session: android.hardware.camera2.CameraCaptureSession) {}
            }, null)
    }

    fun stop() {
        captureSession?.close()
        cameraDevice?.close()
    }
}
