package com.anubis.nvr.service

// ============================================================
//  👁️  Eye of Anubis Android — Built-in Web Server
//  service/NvrWebServer.kt
//
//  RUNS A FULL HTTP SERVER INSIDE ANDROID.
//
//  Uses NanoHTTPD — a tiny Java HTTP server.
//  Serves:
//    - The Anubis Web UI (HTML/CSS/JS from assets)
//    - REST API (same endpoints as Linux server)
//    - Camera snapshots (JPEG)
//    - WebSocket for live events
//    - MJPEG stream for live camera view
//
//  ACCESS FROM SAME WIFI NETWORK:
//    http://phone-ip:8080
//
//  This means you can control the Android NVR from:
//    - Any browser on the same network
//    - The desktop Anubis client
//    - Another phone
// ============================================================

import android.content.Context
import android.util.Log
import com.anubis.nvr.camera.CameraManager
import com.anubis.nvr.storage.StorageManager
import com.anubis.nvr.ai.AiEngine
import com.anubis.nvr.utils.NvrConfig
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException

class NvrWebServer(
    private val context:       Context,
    private val config:        NvrConfig,
    private val cameraManager: CameraManager,
    private val storageManager: StorageManager,
    private val aiEngine:      AiEngine,
) {
    private var httpServer: AnubisHttpServer? = null

    fun start(port: Int) {
        httpServer = AnubisHttpServer(
            context, port, config, cameraManager, storageManager, aiEngine
        )
        httpServer?.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        Log.i("AnubisWebServer", "HTTP server started on port $port")
    }

    fun stop() {
        httpServer?.stop()
        Log.i("AnubisWebServer", "HTTP server stopped")
    }
}

// ─── HTTP Server ──────────────────────────────────────────────

class AnubisHttpServer(
    private val context:        Context,
    port:                       Int,
    private val config:         NvrConfig,
    private val cameraManager:  CameraManager,
    private val storageManager: StorageManager,
    private val aiEngine:       AiEngine,
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        val uri    = session.uri
        val method = session.method

        return try {
            when {
                // ── API routes ────────────────────────────────
                uri == "/api/health"          -> apiHealth()
                uri == "/api/status"          -> apiStatus()
                uri == "/api/cameras"         -> when (method) {
                    Method.GET  -> apiGetCameras()
                    Method.POST -> apiAddCamera(session)
                    else        -> notFound()
                }
                uri.startsWith("/api/cameras/") -> {
                    val id = uri.removePrefix("/api/cameras/").split("/").first()
                    when {
                        uri.endsWith("/snap") -> apiSnapshot(id)
                        uri.endsWith("/stream") -> apiMjpegStream(id)
                        method == Method.DELETE  -> apiDeleteCamera(id)
                        method == Method.PUT     -> apiUpdateCamera(id, session)
                        else -> apiGetCamera(id)
                    }
                }
                uri == "/api/events"          -> apiGetEvents()
                uri == "/api/search"          -> apiSearch(session)
                uri == "/api/storage"         -> apiStorageInfo()
                uri == "/api/license"         -> apiLicense()

                // ── Static Web UI ─────────────────────────────
                uri == "/" || uri == "/index.html" -> serveWebUi()
                uri.startsWith("/static/")    -> serveAsset(uri.removePrefix("/"))
                uri.endsWith(".js")           -> serveAsset("static${uri}")
                uri.endsWith(".css")          -> serveAsset("static${uri}")

                else -> notFound()
            }
        } catch (e: Exception) {
            Log.e("AnubisHTTP", "Error serving $uri: ${e.message}")
            newFixedLengthResponse(
                Response.Status.INTERNAL_ERROR,
                "application/json",
                """{"error":"${e.message}"}"""
            )
        }
    }

    // ─── API Handlers ─────────────────────────────────────────

    private fun apiHealth() = jsonResponse(JSONObject().apply {
        put("status",  "ok")
        put("system",  "Eye of Anubis Android NVR")
        put("version", "1.0.0")
        put("platform","android")
    })

    private fun apiStatus(): Response {
        val state    = NvrServerService.serverState.value
        val cameras  = cameraManager.getCameraStatuses()
        val storagePct = storageManager.getUsagePct()

        return jsonResponse(JSONObject().apply {
            put("success", true)
            val data = JSONObject().apply {
                put("recording",          state.recording)
                put("cameras_online",     cameras.count { it.connected })
                put("cameras_total",      cameras.size)
                put("storage_used_pct",   storagePct)
                put("cpu_pct",            getCpuUsage())
                put("cpu_temp",           getCpuTemp())
                put("ram_pct",            getRamUsage())
                put("uptime_secs",        state.uptime)
                put("platform",           "android")
                put("license",            "active")
                put("events_today",       aiEngine.getEventCount())
            }
            put("data", data)
        })
    }

    private fun apiGetCameras(): Response {
        val cameras  = cameraManager.getCameraStatuses()
        val arr      = JSONArray()
        cameras.forEach { cam ->
            arr.put(JSONObject().apply {
                put("id",            cam.id)
                put("name",          cam.name)
                put("connected",     cam.connected)
                put("recording",     cam.recording)
                put("motion_active", cam.motionActive)
                put("fps_current",   cam.fpsCurrent)
                put("bitrate_kbps",  cam.bitrateKbps)
                put("reconnects",    cam.reconnects)
                put("snapshot_url",  "/api/cameras/${cam.id}/snap")
                put("stream_url",    "/api/cameras/${cam.id}/stream")
            })
        }
        return jsonResponse(JSONObject().apply {
            put("success", true)
            put("data", arr)
        })
    }

    private fun apiAddCamera(session: IHTTPSession): Response {
        val body = parseBody(session)
        val camConfig = com.anubis.nvr.camera.CameraConfig(
            id        = "cam-${System.currentTimeMillis()}",
            name      = body.optString("name", "New Camera"),
            rtspUrl   = body.optString("rtsp_url", ""),
            username  = body.optString("username", ""),
            password  = body.optString("password", ""),
            width     = body.optInt("width", 1280),
            height    = body.optInt("height", 720),
            fps       = body.optInt("fps", 15),
            priority  = body.optString("priority", "normal"),
            aiEnabled = body.optBoolean("ai_enabled", false),
            source    = if (body.optString("source") == "phone")
                com.anubis.nvr.camera.CameraSource.PHONE
                else com.anubis.nvr.camera.CameraSource.RTSP,
        )

        return try {
            cameraManager.addCamera(camConfig)
            jsonResponse(JSONObject().apply {
                put("success", true)
                put("data", JSONObject().apply {
                    put("id",     camConfig.id)
                    put("status", "added")
                })
            })
        } catch (e: Exception) {
            jsonResponse(JSONObject().apply {
                put("success", false)
                put("error",   e.message)
            }, Response.Status.BAD_REQUEST)
        }
    }

    private fun apiDeleteCamera(id: String): Response {
        cameraManager.removeCamera(id)
        return jsonResponse(JSONObject().apply {
            put("success", true)
            put("data", JSONObject().apply { put("deleted", id) })
        })
    }

    private fun apiUpdateCamera(id: String, session: IHTTPSession): Response {
        // In production: update camera config
        return jsonResponse(JSONObject().apply {
            put("success", true)
            put("data", JSONObject().apply { put("updated", id) })
        })
    }

    private fun apiGetCamera(id: String): Response {
        val status = cameraManager.getCameraStatuses().find { it.id == id }
        return if (status != null) {
            jsonResponse(JSONObject().apply {
                put("success", true)
                put("data", JSONObject().apply {
                    put("id", status.id)
                    put("name", status.name)
                    put("connected", status.connected)
                })
            })
        } else {
            notFound()
        }
    }

    private fun apiSnapshot(cameraId: String): Response {
        val snapPath = storageManager.getSnapshotPath(cameraId)
        return if (snapPath != null) {
            val data = java.io.File(snapPath).readBytes()
            newFixedLengthResponse(
                Response.Status.OK,
                "image/jpeg",
                ByteArrayInputStream(data),
                data.size.toLong()
            )
        } else {
            // Return placeholder JPEG
            newFixedLengthResponse(
                Response.Status.OK,
                "image/jpeg",
                ByteArrayInputStream(generatePlaceholderJpeg(cameraId)),
                -1
            )
        }
    }

    private fun apiMjpegStream(cameraId: String): Response {
        // MJPEG: sends a continuous stream of JPEG frames
        // Browser: <img src="/api/cameras/cam-001/stream">
        val response = newChunkedResponse(
            Response.Status.OK,
            "multipart/x-mixed-replace; boundary=anubisboundary",
            MjpegInputStream(cameraManager, cameraId, storageManager)
        )
        return response
    }

    private fun apiGetEvents(): Response {
        val events = aiEngine.getRecentEvents()
        val arr    = JSONArray()
        events.takeLast(50).forEach { ev ->
            arr.put(JSONObject().apply {
                put("id",           ev.id)
                put("camera_id",    ev.cameraId)
                put("camera_name",  ev.cameraName)
                put("type",         ev.type.name.lowercase())
                put("message",      ev.description)
                put("message_ar",   ev.descriptionAr)
                put("timestamp",    ev.timestamp)
                put("time_ago",     timeAgo(ev.timestamp))
                put("read",         false)
            })
        }
        return jsonResponse(JSONObject().apply {
            put("success", true)
            put("data", arr)
        })
    }

    private fun apiSearch(session: IHTTPSession): Response {
        val body  = parseBody(session)
        val query = body.optString("query", "")
        // In production: call vector search engine
        return jsonResponse(JSONObject().apply {
            put("success", true)
            put("data", JSONObject().apply {
                put("query", query)
                put("results", JSONArray())
                put("note", "Vector search coming in next build")
            })
        })
    }

    private fun apiStorageInfo(): Response {
        val options = storageManager.getAvailableOptions()
        val arr     = JSONArray()
        options.forEach { opt ->
            arr.put(JSONObject().apply {
                put("type",       opt.type.name)
                put("label",      opt.label)
                put("total_gb",   opt.totalGb)
                put("free_gb",    opt.freeGb)
                put("enabled",    opt.enabled)
            })
        }
        return jsonResponse(JSONObject().apply {
            put("success", true)
            put("data", JSONObject().apply {
                put("options",     arr)
                put("active",      storageManager.getActiveStorage()?.label ?: "none")
                put("usage_pct",   storageManager.getUsagePct())
            })
        })
    }

    private fun apiLicense() = jsonResponse(JSONObject().apply {
        put("success", true)
        put("data", JSONObject().apply {
            put("status",      "active")
            put("tier",        "android")
            put("customer",    config.ownerName)
            put("max_cameras", config.maxCameras)
            put("platform",    "Android ${android.os.Build.VERSION.RELEASE}")
            put("device",      "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
        })
    })

    // ─── Web UI ───────────────────────────────────────────────

    private fun serveWebUi(): Response {
        return try {
            val html = context.assets.open("webui/index.html").bufferedReader().readText()
            newFixedLengthResponse(Response.Status.OK, "text/html", html)
        } catch (e: Exception) {
            // Serve minimal built-in UI if assets not present
            newFixedLengthResponse(Response.Status.OK, "text/html", MINIMAL_UI_HTML)
        }
    }

    private fun serveAsset(path: String): Response {
        return try {
            val stream = context.assets.open(path)
            val mime   = getMimeType(path)
            newChunkedResponse(Response.Status.OK, mime, stream)
        } catch (_: IOException) {
            notFound()
        }
    }

    // ─── Helpers ──────────────────────────────────────────────

    private fun jsonResponse(json: JSONObject, status: Response.Status = Response.Status.OK) =
        newFixedLengthResponse(status, "application/json", json.toString())

    private fun notFound() = newFixedLengthResponse(
        Response.Status.NOT_FOUND, "application/json", """{"error":"not found"}"""
    )

    private fun parseBody(session: IHTTPSession): JSONObject {
        val body = HashMap<String, String>()
        return try {
            session.parseBody(body)
            JSONObject(body["postData"] ?: "{}")
        } catch (_: Exception) { JSONObject() }
    }

    private fun getMimeType(path: String) = when {
        path.endsWith(".js")   -> "application/javascript"
        path.endsWith(".css")  -> "text/css"
        path.endsWith(".png")  -> "image/png"
        path.endsWith(".jpg")  -> "image/jpeg"
        path.endsWith(".svg")  -> "image/svg+xml"
        path.endsWith(".json") -> "application/json"
        else                   -> "text/plain"
    }

    private fun generatePlaceholderJpeg(cameraId: String): ByteArray {
        val bmp = android.graphics.Bitmap.createBitmap(640, 360, android.graphics.Bitmap.Config.RGB_565)
        val canvas = android.graphics.Canvas(bmp)
        canvas.drawColor(android.graphics.Color.parseColor("#0d0f1a"))
        val out = java.io.ByteArrayOutputStream()
        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 50, out)
        return out.toByteArray()
    }

    private fun timeAgo(timestamp: Long): String {
        val diff = (System.currentTimeMillis() - timestamp) / 1000
        return when {
            diff < 60     -> "${diff}s ago"
            diff < 3600   -> "${diff/60}m ago"
            else          -> "${diff/3600}h ago"
        }
    }

    private fun getCpuUsage(): Float {
        return try {
            val proc = Runtime.getRuntime().exec("top -n 1 -d 0.1")
            val out  = proc.inputStream.bufferedReader().readText()
            val match = Regex("""(\d+\.\d+)%cpu""").find(out)
            match?.groupValues?.get(1)?.toFloat() ?: 0f
        } catch (_: Exception) { 0f }
    }

    private fun getCpuTemp(): Float {
        return try {
            java.io.File("/sys/class/thermal/thermal_zone0/temp")
                .readText().trim().toFloat() / 1000f
        } catch (_: Exception) { 0f }
    }

    private fun getRamUsage(): Float {
        val mi = android.app.ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager)
            .getMemoryInfo(mi)
        return (1f - mi.availMem.toFloat() / mi.totalMem.toFloat()) * 100f
    }
}

// ─── MJPEG Stream ─────────────────────────────────────────────

class MjpegInputStream(
    private val cameraManager:  CameraManager,
    private val cameraId:       String,
    private val storageManager: StorageManager,
) : java.io.InputStream() {
    private var buffer: ByteArray = byteArrayOf()
    private var pos    = 0
    private var done   = false

    override fun read(): Int {
        if (pos >= buffer.size) loadNextFrame()
        if (done) return -1
        return buffer[pos++].toInt() and 0xFF
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (pos >= buffer.size) loadNextFrame()
        if (done) return -1
        val available = minOf(len, buffer.size - pos)
        System.arraycopy(buffer, pos, b, off, available)
        pos += available
        return available
    }

    private fun loadNextFrame() {
        Thread.sleep(66)  // ~15fps

        val snap = storageManager.getSnapshotPath(cameraId)
        val jpeg = if (snap != null) java.io.File(snap).readBytes()
                   else              generateBlankFrame()

        val header = "--anubisboundary\r\nContent-Type: image/jpeg\r\nContent-Length: ${jpeg.size}\r\n\r\n"
        val footer = "\r\n"

        buffer = header.toByteArray() + jpeg + footer.toByteArray()
        pos    = 0
    }

    private fun generateBlankFrame(): ByteArray {
        val bmp = android.graphics.Bitmap.createBitmap(640, 360, android.graphics.Bitmap.Config.RGB_565)
        val out = java.io.ByteArrayOutputStream()
        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 30, out)
        return out.toByteArray()
    }
}

// ─── Minimal Built-in UI ──────────────────────────────────────

private val MINIMAL_UI_HTML = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>👁️ عين أنوبيس</title>
<style>
  body { background:#050508; color:#e8eaf0; font-family:'Cairo',sans-serif; margin:0; padding:20px; }
  h1   { color:#c8992a; text-align:center; }
  .card { background:#0d0f1a; border:1px solid #1a1d2e; border-radius:10px; padding:16px; margin:12px 0; }
  .btn { background:#c8992a; color:#050508; border:none; padding:10px 20px; border-radius:8px;
         cursor:pointer; font-weight:bold; margin:4px; }
  .cam-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:10px; }
  .cam-tile { background:#08090f; border:1px solid #1a1d2e; border-radius:8px; overflow:hidden; }
  .cam-img  { width:100%; aspect-ratio:16/9; object-fit:cover; }
  .cam-name { padding:8px; font-size:0.85rem; color:#c8992a; }
  .stat     { display:inline-block; margin:4px; padding:6px 12px;
               background:#111420; border-radius:20px; font-size:0.8rem; }
  input, select { background:#111420; border:1px solid #1a1d2e; color:#e8eaf0;
                  padding:8px; border-radius:6px; width:100%; margin:4px 0; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<h1>👁️ عين أنوبيس — Android NVR</h1>

<div class="card" id="status-card">
  <div id="stats">جاري التحميل...</div>
</div>

<div class="card">
  <h3 style="color:#7a8299">📷 الكاميرات</h3>
  <div class="cam-grid" id="cam-grid"></div>
  <button class="btn" onclick="showAddCamera()">+ إضافة كاميرا</button>
</div>

<div class="card" id="add-cam-form" style="display:none">
  <h3 style="color:#7a8299">إضافة كاميرا جديدة</h3>
  <input id="cam-name"  placeholder="اسم الكاميرا (مثال: المدخل الرئيسي)" />
  <input id="cam-rtsp"  placeholder="RTSP URL (مثال: rtsp://192.168.1.100/stream1)" dir="ltr"/>
  <input id="cam-user"  placeholder="اسم المستخدم" />
  <input id="cam-pass"  type="password" placeholder="كلمة المرور" />
  <select id="cam-source">
    <option value="rtsp">كاميرا شبكية (RTSP)</option>
    <option value="phone">كاميرا الهاتف</option>
  </select>
  <button class="btn" onclick="addCamera()">إضافة</button>
  <button class="btn" style="background:#333;color:#aaa" onclick="hideAddCamera()">إلغاء</button>
</div>

<div class="card">
  <h3 style="color:#7a8299">🔔 آخر الأحداث</h3>
  <div id="events-list"></div>
</div>

<script>
async function load() {
  // Status
  const s = await fetch('/api/status').then(r=>r.json()).catch(()=>({}));
  const d = s.data || {};
  document.getElementById('stats').innerHTML = `
    <span class="stat">📷 ${d.cameras_online||0}/${d.cameras_total||0} كاميرا</span>
    <span class="stat">💾 ${Math.round(d.storage_used_pct||0)}%</span>
    <span class="stat">🖥️ CPU ${Math.round(d.cpu_pct||0)}%</span>
    <span class="stat" style="color:#c8992a">🌐 http://${location.host}</span>
  `;

  // Cameras
  const cams = await fetch('/api/cameras').then(r=>r.json()).catch(()=>({data:[]}));
  const grid = document.getElementById('cam-grid');
  grid.innerHTML = (cams.data||[]).map(c=>`
    <div class="cam-tile">
      <img class="cam-img" src="/api/cameras/${c.id}/snap?t=${Date.now()}" onerror="this.style.opacity=0.3" />
      <div class="cam-name">
        ${c.name}
        <span style="color:${c.connected?'#30d158':'#ff2d55'};font-size:0.7rem">
          ${c.connected?'● متصل':'○ غير متصل'}
        </span>
      </div>
    </div>
  `).join('') || '<div style="color:#3d4258;padding:20px">لا توجد كاميرات — أضف كاميرا للبدء</div>';

  // Events
  const evs = await fetch('/api/events').then(r=>r.json()).catch(()=>({data:[]}));
  document.getElementById('events-list').innerHTML =
    (evs.data||[]).slice(0,5).map(e=>`
      <div style="padding:8px;border-bottom:1px solid #1a1d2e">
        <span style="color:#c8992a">${e.camera_name}</span>
        <span style="color:#7a8299;font-size:0.8rem;margin:0 8px">${e.time_ago}</span>
        <br><span style="font-family:Cairo">${e.message_ar}</span>
      </div>
    `).join('') || '<div style="color:#3d4258;padding:10px">لا أحداث بعد</div>';
}

function showAddCamera() { document.getElementById('add-cam-form').style.display='block'; }
function hideAddCamera() { document.getElementById('add-cam-form').style.display='none'; }

async function addCamera() {
  const body = {
    name:      document.getElementById('cam-name').value,
    rtsp_url:  document.getElementById('cam-rtsp').value,
    username:  document.getElementById('cam-user').value,
    password:  document.getElementById('cam-pass').value,
    source:    document.getElementById('cam-source').value,
    width: 1280, height: 720, fps: 15,
  };
  const res = await fetch('/api/cameras', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body)
  }).then(r=>r.json());
  if (res.success) { hideAddCamera(); load(); alert('✅ تمت إضافة الكاميرا'); }
  else alert('❌ خطأ: ' + (res.error || 'فشل الاتصال'));
}

load();
setInterval(load, 5000);
</script>
</body>
</html>
""".trimIndent()
