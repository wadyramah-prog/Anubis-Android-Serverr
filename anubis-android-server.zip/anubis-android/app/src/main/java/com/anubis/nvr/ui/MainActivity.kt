package com.anubis.nvr.ui

// ============================================================
//  👁️  Eye of Anubis Android NVR — Main Activity
//  ui/MainActivity.kt
//
//  Jetpack Compose UI — Egyptian Cyber-Noir theme
//  Screens:
//    - Dashboard    (server stats + live camera grid)
//    - Cameras      (manage cameras)
//    - Recordings   (browse + play)
//    - Events       (AI alerts)
//    - Settings     (storage, config, license)
// ============================================================

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import com.anubis.nvr.service.NvrServerService
import com.anubis.nvr.service.NvrServerState
import com.anubis.nvr.utils.NetworkUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ─── Colors ──────────────────────────────────────────────────

object AnubisColors {
    val bg       = Color(0xFF050508)
    val surface  = Color(0xFF0D0F1A)
    val raised   = Color(0xFF111420)
    val gold     = Color(0xFFC8992A)
    val goldBright = Color(0xFFF0B429)
    val cyan     = Color(0xFF00D4FF)
    val red      = Color(0xFFFF2D55)
    val green    = Color(0xFF30D158)
    val amber    = Color(0xFFFF9500)
    val muted    = Color(0xFF7A8299)
    val border   = Color(0xFF1A1D2E)
    val text     = Color(0xFFE8EAF0)
}

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val allGranted = perms.all { it.value }
        if (allGranted) startNvrServer()
        else Toast.makeText(this, "⚠️ Some permissions denied — NVR may not work fully", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AnubisNvrTheme {
                AnubisApp(
                    onStartServer = { checkPermissionsAndStart() },
                    onStopServer  = { NvrServerService.stop(this) },
                )
            }
        }
    }

    private fun checkPermissionsAndStart() {
        val required = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS,
        )
        val missing = required.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startNvrServer()
        else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startNvrServer() = NvrServerService.start(this)
}

// ─── Theme ────────────────────────────────────────────────────

@Composable
fun AnubisNvrTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary         = AnubisColors.gold,
            secondary       = AnubisColors.cyan,
            error           = AnubisColors.red,
            background      = AnubisColors.bg,
            surface         = AnubisColors.surface,
            onBackground    = AnubisColors.text,
            onSurface       = AnubisColors.text,
        ),
        content = content
    )
}

// ─── Root App ─────────────────────────────────────────────────

@Composable
fun AnubisApp(
    onStartServer: () -> Unit,
    onStopServer:  () -> Unit,
) {
    val serverState by NvrServerService.serverState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    val context     = LocalContext.current

    Scaffold(
        containerColor = AnubisColors.bg,
        topBar = {
            AnubisTopBar(serverState, onStartServer, onStopServer)
        },
        bottomBar = {
            AnubisBottomBar(selectedTab) { selectedTab = it }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> DashboardScreen(serverState)
                1 -> CamerasScreen()
                2 -> RecordingsScreen()
                3 -> EventsScreen()
                4 -> SettingsScreen(onStartServer, onStopServer)
            }
        }
    }
}

// ─── Top Bar ──────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnubisTopBar(
    state:         NvrServerState,
    onStart:       () -> Unit,
    onStop:        () -> Unit,
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(0xFF08090F),
        ),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("👁️ ", fontSize = 20.sp)
                Column {
                    Text(
                        "عين أنوبيس",
                        color    = AnubisColors.gold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        if (state.running) "● RECORDING" else "○ STOPPED",
                        color    = if (state.running) AnubisColors.red else AnubisColors.muted,
                        fontSize = 10.sp,
                        letterSpacing = 1.sp,
                    )
                }
            }
        },
        actions = {
            if (state.running && state.serverIp.isNotEmpty()) {
                Text(
                    "http://${state.serverIp}:${state.webPort}",
                    color    = AnubisColors.cyan,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(end = 8.dp),
                )
            }
            IconButton(
                onClick = if (state.running) onStop else onStart
            ) {
                Icon(
                    imageVector = if (state.running) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = if (state.running) "Stop" else "Start",
                    tint = if (state.running) AnubisColors.red else AnubisColors.green,
                )
            }
        }
    )
}

// ─── Bottom Bar ───────────────────────────────────────────────

@Composable
fun AnubisBottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF08090F)) {
        listOf(
            Triple(Icons.Default.GridView,      "بث مباشر",  "Live"),
            Triple(Icons.Default.Videocam,       "كاميرات",  "Cameras"),
            Triple(Icons.Default.VideoLibrary,   "تسجيلات",  "Recordings"),
            Triple(Icons.Default.Notifications,  "أحداث",    "Events"),
            Triple(Icons.Default.Settings,       "إعدادات",  "Settings"),
        ).forEachIndexed { i, (icon, labelAr, labelEn) ->
            NavigationBarItem(
                icon     = { Icon(icon, labelEn) },
                label    = { Text(labelAr, fontSize = 10.sp) },
                selected = selected == i,
                onClick  = { onSelect(i) },
                colors   = NavigationBarItemDefaults.colors(
                    selectedIconColor     = AnubisColors.gold,
                    selectedTextColor     = AnubisColors.gold,
                    unselectedIconColor   = AnubisColors.muted,
                    unselectedTextColor   = AnubisColors.muted,
                    indicatorColor        = AnubisColors.gold.copy(alpha = 0.1f),
                )
            )
        }
    }
}

// ─── Dashboard Screen ─────────────────────────────────────────

@Composable
fun DashboardScreen(state: NvrServerState) {
    var cameras by remember { mutableStateOf<List<com.anubis.nvr.camera.CameraStatus>>(emptyList()) }
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        while (true) {
            // Poll camera statuses
            delay(2000)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Server status strip
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                StatCard("📷", "${state.camerasOnline}/${state.camerasTotal}", "Cameras", AnubisColors.cyan, Modifier.weight(1f))
                StatCard("💾", "${state.storageUsedPct.toInt()}%", "Storage",
                    if (state.storageUsedPct > 85) AnubisColors.red else AnubisColors.green, Modifier.weight(1f))
                StatCard("🔔", "${state.eventsToday}", "Events", AnubisColors.amber, Modifier.weight(1f))
            }
        }

        // Server URL card
        if (state.serverIp.isNotEmpty()) {
            item {
                Card(
                    colors  = CardDefaults.cardColors(containerColor = AnubisColors.surface),
                    border  = BorderStroke(1.dp, AnubisColors.cyan.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("🌐", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Web UI متاح على الشبكة", color = AnubisColors.muted, fontSize = 11.sp)
                            Text(
                                "http://${state.serverIp}:${state.webPort}",
                                color    = AnubisColors.cyan,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp,
                            )
                        }
                    }
                }
            }
        }

        // Camera grid
        item {
            Text(
                "الكاميرات المباشرة",
                color     = AnubisColors.muted,
                fontSize  = 11.sp,
                letterSpacing = 1.sp,
            )
        }

        if (cameras.isEmpty()) {
            item {
                Card(
                    colors  = CardDefaults.cardColors(containerColor = AnubisColors.surface),
                    border  = BorderStroke(1.dp, AnubisColors.border),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(40.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("📷", fontSize = 40.sp)
                        Text("لا توجد كاميرات", color = AnubisColors.muted, fontFamily = arabicFamily())
                        Text("اضغط على 'كاميرات' لإضافة كاميرا",
                            color = AnubisColors.border, fontSize = 12.sp, fontFamily = arabicFamily())
                    }
                }
            }
        }

        // Camera tiles in 2-column grid
        items(cameras.chunked(2)) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                row.forEach { cam ->
                    CameraTile(cam, Modifier.weight(1f))
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun StatCard(
    icon:     String,
    value:    String,
    label:    String,
    color:    Color,
    modifier: Modifier = Modifier,
) {
    Card(
        colors   = CardDefaults.cardColors(containerColor = AnubisColors.surface),
        border   = BorderStroke(1.dp, AnubisColors.border),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(icon, fontSize = 18.sp)
            Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(label, color = AnubisColors.muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun CameraTile(cam: com.anubis.nvr.camera.CameraStatus, modifier: Modifier = Modifier) {
    Card(
        colors   = CardDefaults.cardColors(containerColor = AnubisColors.raised),
        border   = BorderStroke(
            1.dp,
            if (cam.motionActive) AnubisColors.amber.copy(alpha = 0.5f) else AnubisColors.border
        ),
        modifier = modifier.aspectRatio(16f / 9f),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Placeholder
            Box(
                modifier = Modifier.fillMaxSize().background(AnubisColors.bg),
                contentAlignment = Alignment.Center,
            ) {
                Text(if (cam.connected) "📷" else "📷", fontSize = 24.sp, color = AnubisColors.border)
            }

            // Status overlay
            Row(
                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                if (cam.connected) {
                    Text("● REC",
                        color    = AnubisColors.red,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(AnubisColors.bg.copy(alpha = 0.7f), MaterialTheme.shapes.small)
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                    )
                }
            }

            // Name overlay
            Text(
                cam.name,
                color    = AnubisColors.text,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(AnubisColors.bg.copy(alpha = 0.7f))
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                fontFamily = arabicFamily(),
            )
        }
    }
}

// ─── Cameras Screen ───────────────────────────────────────────

@Composable
fun CamerasScreen() {
    // Full camera management — add/remove/edit
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("📷 Camera Management\n\nAdd cameras via the Web UI:\nhttp://phone-ip:8080/cameras",
            color    = AnubisColors.muted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

// ─── Recordings Screen ────────────────────────────────────────

@Composable
fun RecordingsScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("◉ Recordings\n\nBrowse and play recordings\nvia Web UI: http://phone-ip:8080/recordings",
            color    = AnubisColors.muted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

// ─── Events Screen ────────────────────────────────────────────

@Composable
fun EventsScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("🔔 AI Events\n\nView real-time detection events",
            color = AnubisColors.muted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

// ─── Settings Screen ──────────────────────────────────────────

@Composable
fun SettingsScreen(onStart: () -> Unit, onStop: () -> Unit) {
    val state   = NvrServerService.serverState.collectAsState().value
    val context = LocalContext.current

    LazyColumn(
        modifier       = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("الإعدادات", color = AnubisColors.muted, fontSize = 11.sp, letterSpacing = 1.sp)
        }

        item {
            Card(
                colors   = CardDefaults.cardColors(containerColor = AnubisColors.surface),
                border   = BorderStroke(1.dp, AnubisColors.gold.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🖥️ NVR Server", color = AnubisColors.gold, fontWeight = FontWeight.Bold)
                    Text(
                        if (state.running) "✅ يعمل على http://${state.serverIp}:${state.webPort}"
                        else "⏹️ متوقف",
                        color    = if (state.running) AnubisColors.green else AnubisColors.muted,
                        fontSize = 13.sp,
                        fontFamily = arabicFamily(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick  = onStart,
                            enabled  = !state.running,
                            colors   = ButtonDefaults.buttonColors(containerColor = AnubisColors.green),
                        ) { Text("▶ Start") }
                        Button(
                            onClick  = onStop,
                            enabled  = state.running,
                            colors   = ButtonDefaults.buttonColors(containerColor = AnubisColors.red),
                        ) { Text("■ Stop") }
                    }
                }
            }
        }

        item {
            Card(
                colors   = CardDefaults.cardColors(containerColor = AnubisColors.surface),
                border   = BorderStroke(1.dp, AnubisColors.border),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📱 معلومات الجهاز", color = AnubisColors.muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    Text("${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", color = AnubisColors.text)
                    Text("Android ${android.os.Build.VERSION.RELEASE}", color = AnubisColors.muted)
                    Text(
                        "RAM: ${getRamInfo(context)}",
                        color    = AnubisColors.cyan,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 12.sp,
                    )
                }
            }
        }
    }
}

// ─── Helpers ──────────────────────────────────────────────────

fun arabicFamily() = FontFamily.Default

fun getRamInfo(context: android.content.Context): String {
    val mi = android.app.ActivityManager.MemoryInfo()
    (context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager)
        .getMemoryInfo(mi)
    val total = mi.totalMem / 1_048_576
    val avail = mi.availMem / 1_048_576
    return "${total - avail}MB / ${total}MB"
}
