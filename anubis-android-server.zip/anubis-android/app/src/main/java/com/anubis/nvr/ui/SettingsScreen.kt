package com.anubis.nvr.ui

// ============================================================
//  👁️  Eye of Anubis Android — Full Settings Screen
//  ui/SettingsScreen.kt
// ============================================================

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import com.anubis.nvr.service.NvrServerService
import kotlinx.coroutines.launch

@Composable
fun FullSettingsScreen(
    onStart: () -> Unit,
    onStop:  () -> Unit,
) {
    val context = LocalContext.current
    val state   = NvrServerService.serverState.collectAsState().value
    val scope   = rememberCoroutineScope()
    val snack   = remember { SnackbarHostState() }

    // Settings state
    var webPort         by remember { mutableStateOf("8080") }
    var maxCameras      by remember { mutableStateOf("4") }
    var retentionDays   by remember { mutableStateOf("7") }
    var ownerName       by remember { mutableStateOf("") }
    var startOnBoot     by remember { mutableStateOf(true) }
    var aiEnabled       by remember { mutableStateOf(true) }
    var tgToken         by remember { mutableStateOf("") }
    var tgChat          by remember { mutableStateOf("") }
    var storageFolderUri by remember { mutableStateOf<Uri?>(null) }
    var cloudType       by remember { mutableStateOf("none") }
    var ftpHost         by remember { mutableStateOf("") }
    var ftpUser         by remember { mutableStateOf("") }
    var ftpPass         by remember { mutableStateOf("") }

    // SAF folder picker
    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            // Persist permission
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            storageFolderUri = uri
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snack) }) { pad ->
        LazyColumn(
            modifier       = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {

            // ── Server Control ─────────────────────────────────
            item {
                SettingsSection("🖥️ الخادم") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick  = onStart,
                            enabled  = !state.running,
                            modifier = Modifier.weight(1f),
                            colors   = ButtonDefaults.buttonColors(containerColor = AnubisColors.green),
                        ) { Text("▶ تشغيل") }

                        Button(
                            onClick  = onStop,
                            enabled  = state.running,
                            modifier = Modifier.weight(1f),
                            colors   = ButtonDefaults.buttonColors(containerColor = AnubisColors.red),
                        ) { Text("■ إيقاف") }
                    }

                    if (state.running) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "🌐 http://${state.serverIp}:${state.webPort}",
                            color = AnubisColors.cyan,
                            fontSize = 13.sp,
                            letterSpacing = 0.5.sp,
                        )
                        Text(
                            "افتح هذا الرابط من أي متصفح على نفس الشبكة",
                            color    = AnubisColors.muted,
                            fontSize = 11.sp,
                        )
                    }
                }
            }

            // ── Basic Config ───────────────────────────────────
            item {
                SettingsSection("⚙️ الإعدادات الأساسية") {
                    AnubisTextField("اسم النظام", ownerName) { ownerName = it }
                    AnubisTextField("منفذ الويب (Port)", webPort) { webPort = it }
                    AnubisTextField("أقصى عدد كاميرات", maxCameras) { maxCameras = it }
                    AnubisTextField("أيام الاحتفاظ بالتسجيلات", retentionDays) { retentionDays = it }

                    Spacer(Modifier.height(4.dp))
                    AnubisSwitchRow("تشغيل عند الإقلاع", startOnBoot) { startOnBoot = it }
                    AnubisSwitchRow("تفعيل الذكاء الاصطناعي", aiEnabled) { aiEnabled = it }
                }
            }

            // ── Storage ────────────────────────────────────────
            item {
                SettingsSection("💾 التخزين") {
                    // Current storage info
                    Text(
                        "مجلد التخزين الحالي:",
                        color    = AnubisColors.muted,
                        fontSize = 11.sp,
                    )
                    Text(
                        storageFolderUri?.path ?: "التخزين الداخلي (افتراضي)",
                        color    = AnubisColors.cyan,
                        fontSize = 12.sp,
                        letterSpacing = 0.3.sp,
                    )

                    Spacer(Modifier.height(8.dp))

                    // Storage options
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick  = { folderPicker.launch(null) },
                            modifier = Modifier.weight(1f),
                            colors   = OutlinedButtonDefaults.outlinedButtonColors(
                                contentColor = AnubisColors.gold
                            ),
                            border = BorderStroke(1.dp, AnubisColors.gold.copy(0.5f)),
                        ) { Text("📂 اختر مجلد", fontSize = 12.sp) }

                        OutlinedButton(
                            onClick  = { storageFolderUri = null },
                            modifier = Modifier.weight(1f),
                            colors   = OutlinedButtonDefaults.outlinedButtonColors(
                                contentColor = AnubisColors.muted
                            ),
                            border = BorderStroke(1.dp, AnubisColors.border),
                        ) { Text("↩ داخلي", fontSize = 12.sp) }
                    }

                    Spacer(Modifier.height(4.dp))
                    Text(
                        "💡 يمكنك اختيار: بطاقة SD، USB OTG، أي مجلد",
                        color    = AnubisColors.muted,
                        fontSize = 10.sp,
                    )
                }
            }

            // ── Cloud Upload ───────────────────────────────────
            item {
                SettingsSection("☁️ التحميل السحابي") {
                    // Cloud type selector
                    val cloudOptions = listOf(
                        "none"    to "❌ لا يوجد",
                        "ftp"     to "📡 FTP/SFTP",
                        "webdav"  to "🔗 WebDAV (Nextcloud)",
                        "smb"     to "📁 SMB/NAS",
                        "gdrive"  to "🟢 Google Drive",
                    )

                    Text("نوع التخزين السحابي:", color = AnubisColors.muted, fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))

                    cloudOptions.forEach { (id, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { cloudType = id }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = cloudType == id,
                                onClick  = { cloudType = id },
                                colors   = RadioButtonDefaults.colors(
                                    selectedColor = AnubisColors.gold
                                ),
                            )
                            Text(label, color = AnubisColors.text, fontSize = 13.sp)
                        }
                    }

                    // FTP config
                    if (cloudType == "ftp") {
                        Spacer(Modifier.height(8.dp))
                        AnubisTextField("FTP Host", ftpHost) { ftpHost = it }
                        AnubisTextField("Username", ftpUser) { ftpUser = it }
                        AnubisTextField("Password", ftpPass, password = true) { ftpPass = it }
                    }

                    // Google Drive
                    if (cloudType == "gdrive") {
                        Spacer(Modifier.height(8.dp))
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = AnubisColors.raised
                            ),
                            border = BorderStroke(1.dp, AnubisColors.border),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    "Google Drive يحتاج OAuth2 Token",
                                    color    = AnubisColors.gold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "1. روح Google Cloud Console\n" +
                                    "2. أنشئ OAuth2 credentials\n" +
                                    "3. احصل على Access Token\n" +
                                    "4. الصقه في الإعدادات",
                                    color    = AnubisColors.muted,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                )
                            }
                        }
                    }
                }
            }

            // ── Telegram ───────────────────────────────────────
            item {
                SettingsSection("📱 تنبيهات Telegram") {
                    AnubisTextField("Bot Token", tgToken) { tgToken = it }
                    AnubisTextField("Chat ID", tgChat) { tgChat = it }

                    Spacer(Modifier.height(4.dp))
                    Text(
                        "📌 كيف تحصل على Chat ID:\n" +
                        "1. ابعت رسالة للبوت\n" +
                        "2. افتح: api.telegram.org/bot<TOKEN>/getUpdates\n" +
                        "3. خذ الـ chat.id من الرد",
                        color    = AnubisColors.muted,
                        fontSize = 10.sp,
                        lineHeight = 15.sp,
                    )

                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                snack.showSnackbar("📱 تم إرسال رسالة اختبار لـ Telegram")
                            }
                        },
                        enabled = tgToken.isNotBlank() && tgChat.isNotBlank(),
                        colors  = ButtonDefaults.buttonColors(containerColor = AnubisColors.raised),
                        border  = BorderStroke(1.dp, AnubisColors.border),
                    ) {
                        Text("🧪 اختبار الاتصال", color = AnubisColors.text)
                    }
                }
            }

            // ── Device Info ────────────────────────────────────
            item {
                SettingsSection("📱 معلومات الجهاز") {
                    DeviceInfoRow("الجهاز", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                    DeviceInfoRow("Android", android.os.Build.VERSION.RELEASE)
                    DeviceInfoRow("RAM", getRamInfo(context))
                    DeviceInfoRow("Storage", getStorageInfo())
                    DeviceInfoRow("نسخة النظام", "Eye of Anubis v1.0.0")
                }
            }

            // ── Save Button ────────────────────────────────────
            item {
                Button(
                    onClick = {
                        // Save settings to DataStore
                        scope.launch {
                            snack.showSnackbar("✅ تم حفظ الإعدادات")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors   = ButtonDefaults.buttonColors(containerColor = AnubisColors.gold),
                ) {
                    Text("💾 حفظ الإعدادات", color = Color.Black, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

// ─── Composable helpers ───────────────────────────────────────

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors   = CardDefaults.cardColors(containerColor = AnubisColors.surface),
        border   = BorderStroke(1.dp, AnubisColors.border),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                title,
                color      = AnubisColors.gold,
                fontSize   = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
            )
            Divider(color = AnubisColors.border)
            content()
        }
    }
}

@Composable
fun AnubisTextField(
    label:    String,
    value:    String,
    password: Boolean = false,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value         = value,
        onValueChange = onChange,
        label         = { Text(label, fontSize = 12.sp) },
        modifier      = Modifier.fillMaxWidth(),
        singleLine    = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = AnubisColors.gold,
            unfocusedBorderColor = AnubisColors.border,
            focusedLabelColor    = AnubisColors.gold,
            unfocusedLabelColor  = AnubisColors.muted,
            cursorColor          = AnubisColors.gold,
            focusedTextColor     = AnubisColors.text,
            unfocusedTextColor   = AnubisColors.text,
        ),
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
    )
}

@Composable
fun AnubisSwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = AnubisColors.text, fontSize = 13.sp)
        Switch(
            checked   = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor  = AnubisColors.gold,
                checkedTrackColor  = AnubisColors.gold.copy(alpha = 0.3f),
                uncheckedThumbColor = AnubisColors.muted,
                uncheckedTrackColor = AnubisColors.border,
            ),
        )
    }
}

@Composable
fun DeviceInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = AnubisColors.muted, fontSize = 12.sp)
        Text(value, color = AnubisColors.text,  fontSize = 12.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
    }
}

private fun getStorageInfo(): String {
    val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
    val free = stat.availableBytes / 1_073_741_824
    val total = stat.totalBytes / 1_073_741_824
    return "${total - free}GB / ${total}GB"
}
