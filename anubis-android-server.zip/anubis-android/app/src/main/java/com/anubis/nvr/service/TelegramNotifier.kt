package com.anubis.nvr.service

// ============================================================
//  👁️  Eye of Anubis Android — Telegram Notifications
//  service/TelegramNotifier.kt
//
//  يرسل تنبيهات الكاميرا عبر Telegram:
//    - صورة الحدث (JPEG snapshot)
//    - وصف بالعربية
//    - وقت الحدث
//    - اسم الكاميرا
//    - فيديو 5 ثوانٍ للأحداث الحرجة (اختياري)
//
//  Rate Limiting:
//    - نفس الكاميرا + نفس النوع → مرة كل 60 ثانية
//    - Fire/Weapon → فوري بدون تأخير
// ============================================================

import android.content.Context
import android.util.Log
import com.anubis.nvr.ai.AiEvent
import com.anubis.nvr.ai.EventType
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

class TelegramNotifier(
    private val context: Context,
    private val scope:   CoroutineScope,
) {
    companion object {
        private const val TAG            = "AnubisTelegram"
        private const val API_BASE       = "https://api.telegram.org/bot"
        private const val RATE_LIMIT_MS  = 60_000L   // 60 seconds
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    // Rate limiting: cameraId+eventType → last sent time
    private val lastSent = mutableMapOf<String, Long>()

    private var botToken:  String? = null
    private var chatId:    String? = null
    private var enabled:   Boolean = false

    // ─── Configure ────────────────────────────────────────────

    fun configure(token: String, chat: String) {
        botToken = token
        chatId   = chat
        enabled  = token.isNotBlank() && chat.isNotBlank()
        if (enabled) Log.i(TAG, "Telegram notifications enabled (chat: $chat)")
    }

    // ─── Send Alert ───────────────────────────────────────────

    fun sendAlert(
        event:        AiEvent,
        snapshotPath: String? = null,
    ) {
        if (!enabled) return

        // Rate limiting (fire/weapon = always send)
        val isCritical = event.type == EventType.FALL ||
            event.detections.any { it.isCritical }

        if (!isCritical) {
            val key     = "${event.cameraId}_${event.type}"
            val lastMs  = lastSent[key] ?: 0L
            if (System.currentTimeMillis() - lastMs < RATE_LIMIT_MS) {
                Log.d(TAG, "Rate limited: $key")
                return
            }
            lastSent[key] = System.currentTimeMillis()
        }

        scope.launch(Dispatchers.IO) {
            try {
                if (snapshotPath != null && File(snapshotPath).exists()) {
                    sendPhoto(event, File(snapshotPath))
                } else {
                    sendText(event)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Telegram send failed: ${e.message}")
            }
        }
    }

    // ─── Send Text Message ────────────────────────────────────

    private fun sendText(event: AiEvent) {
        val token  = botToken ?: return
        val chat   = chatId   ?: return
        val emoji  = getEmoji(event)
        val time   = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date(event.timestamp))

        val text = buildString {
            appendLine("$emoji *${getEventTitle(event)}*")
            appendLine()
            appendLine("📷 الكاميرا: *${event.cameraName}*")
            appendLine("🕒 الوقت: $time")
            appendLine()
            appendLine("📝 ${event.descriptionAr}")
            if (event.detections.isNotEmpty()) {
                appendLine()
                appendLine("🔍 الكشف: ${event.detections.joinToString(", ") {
                    "${it.className} (${(it.confidence * 100).toInt()}%)"
                }}")
            }
            appendLine()
            appendLine("_نظام عين أنوبيس_")
        }

        val json = JSONObject().apply {
            put("chat_id",    chat)
            put("text",       text)
            put("parse_mode", "Markdown")
        }

        val request = Request.Builder()
            .url("${API_BASE}${token}/sendMessage")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = http.newCall(request).execute()
        if (!response.isSuccessful) {
            Log.e(TAG, "Telegram text failed: ${response.code} — ${response.body?.string()}")
        } else {
            Log.i(TAG, "✅ Telegram text sent: ${event.type}")
        }
    }

    // ─── Send Photo ───────────────────────────────────────────

    private fun sendPhoto(event: AiEvent, photo: File) {
        val token  = botToken ?: return
        val chat   = chatId   ?: return
        val emoji  = getEmoji(event)
        val time   = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date(event.timestamp))

        val caption = buildString {
            appendLine("$emoji *${getEventTitle(event)}*")
            append("📷 ${event.cameraName}  🕒 $time")
            if (event.descriptionAr.isNotBlank()) {
                appendLine()
                append("📝 ${event.descriptionAr}")
            }
        }

        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("chat_id",    chat)
            .addFormDataPart("caption",    caption)
            .addFormDataPart("parse_mode", "Markdown")
            .addFormDataPart(
                "photo", photo.name,
                photo.readBytes().toRequestBody("image/jpeg".toMediaType())
            )
            .build()

        val request = Request.Builder()
            .url("${API_BASE}${token}/sendPhoto")
            .post(body)
            .build()

        val response = http.newCall(request).execute()
        if (!response.isSuccessful) {
            Log.e(TAG, "Telegram photo failed: ${response.code}")
            // Fallback to text
            sendText(event)
        } else {
            Log.i(TAG, "✅ Telegram photo sent: ${event.type}")
        }
    }

    // ─── Send Video Clip ──────────────────────────────────────

    fun sendVideoClip(event: AiEvent, clipPath: String) {
        if (!enabled) return
        scope.launch(Dispatchers.IO) {
            val token = botToken ?: return@launch
            val chat  = chatId  ?: return@launch
            val clip  = File(clipPath)
            if (!clip.exists()) return@launch

            val caption = "🎬 ${getEventTitle(event)} — ${event.cameraName}"

            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chat)
                .addFormDataPart("caption", caption)
                .addFormDataPart(
                    "video", clip.name,
                    clip.readBytes().toRequestBody("video/mp4".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url("${API_BASE}${token}/sendVideo")
                .post(body)
                .build()

            try {
                http.newCall(request).execute()
                Log.i(TAG, "✅ Telegram video clip sent")
            } catch (e: Exception) {
                Log.e(TAG, "Telegram video failed: ${e.message}")
            }
        }
    }

    // ─── Test Connection ──────────────────────────────────────

    suspend fun testConnection(): Boolean = withContext(Dispatchers.IO) {
        val token = botToken ?: return@withContext false
        val chat  = chatId  ?: return@withContext false
        try {
            val json = JSONObject().apply {
                put("chat_id", chat)
                put("text",    "👁️ عين أنوبيس — اختبار الاتصال ✅\nNVR Android Server connected!")
            }
            val req = Request.Builder()
                .url("${API_BASE}${token}/sendMessage")
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val res = http.newCall(req).execute()
            res.isSuccessful
        } catch (_: Exception) { false }
    }

    // ─── Helpers ──────────────────────────────────────────────

    private fun getEmoji(event: AiEvent) = when (event.type) {
        EventType.FALL      -> "🚨"
        EventType.TAMPERING -> "🚨"
        EventType.LOITERING -> "⚠️"
        EventType.MOTION    -> "🔴"
        EventType.DETECTION -> when {
            event.detections.any { it.className == "fire"   } -> "🔥"
            event.detections.any { it.className == "weapon" } -> "⚠️"
            event.detections.any { it.className == "person" } -> "👤"
            event.detections.any { it.className == "car"    } -> "🚗"
            else -> "📷"
        }
    }

    private fun getEventTitle(event: AiEvent) = when (event.type) {
        EventType.FALL      -> "سقوط شخص مكتشف!"
        EventType.TAMPERING -> "تلاعب بالكاميرا!"
        EventType.LOITERING -> "تسكع مكتشف"
        EventType.MOTION    -> "حركة مكتشفة"
        EventType.DETECTION -> when {
            event.detections.any { it.className == "fire"   } -> "حريق مكتشف!"
            event.detections.any { it.className == "weapon" } -> "سلاح مكتشف!"
            else -> "اكتشاف ذكاء اصطناعي"
        }
    }
}
