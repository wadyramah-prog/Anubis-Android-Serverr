package com.anubis.nvr.storage

// ============================================================
//  👁️  Eye of Anubis Android — Storage Manager
//  storage/StorageManager.kt
//
//  STORAGE OPTIONS (user picks from Settings):
//
//  1. INTERNAL STORAGE
//     /data/user/0/com.anubis.nvr/files/recordings/
//     Always available. Limited by phone storage.
//     Best for: phones with 128GB+
//
//  2. SD CARD / USB OTG
//     Via Android Storage Access Framework (SAF)
//     User picks folder → we get persistent URI permission
//     Supports: SD cards, USB drives, USB HDDs (OTG)
//     Best for: long-term recording with external drive
//
//  3. GOOGLE DRIVE / ONEDRIVE / FTP
//     Upload completed segments to cloud
//     Works with any provider that has write permissions
//     Best for: remote backup, always-on upload
//
//  4. NETWORK PATH (SMB/NFS)
//     Write directly to a NAS on the local network
//     Best for: home/office setup with NAS server
//
//  RECORDING FORMAT:
//     Segments: 30-minute .mp4 files (H.265)
//     Index:    hashchain.jsonl (forensic integrity)
//     Snapshots: latest frame per camera (JPEG)
// ============================================================

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import com.anubis.nvr.utils.NvrConfig
import kotlinx.coroutines.*
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.security.MessageDigest

// ─── Storage Types ───────────────────────────────────────────

enum class StorageType { INTERNAL, SD_CARD, USB_OTG, GOOGLE_DRIVE, FTP, SMB }

data class StorageOption(
    val type:      StorageType,
    val label:     String,
    val path:      String,
    val uri:       Uri?    = null,
    val totalGb:   Double  = 0.0,
    val freeGb:    Double  = 0.0,
    val enabled:   Boolean = true,
)

data class RecordingSegment(
    val cameraId:   String,
    val filePath:   String,
    val uri:        Uri?,
    val startTime:  Long,
    val endTime:    Long,
    val sizeBytes:  Long,
    val sha256:     String,
    val frameCount: Int,
)

// ─── Storage Manager ─────────────────────────────────────────

class StorageManager(
    private val context: Context,
    private val config:  NvrConfig,
) {
    companion object {
        private const val TAG             = "AnubisStorage"
        private const val SEGMENT_MINUTES = 30
        private const val MIN_FREE_GB     = 2.0  // Stop recording if < 2GB free
    }

    // Active segment writers per camera
    private val activeSegments = mutableMapOf<String, SegmentWriter>()
    private val completedSegments = mutableListOf<RecordingSegment>()

    // Available storage options
    private var storageOptions = mutableListOf<StorageOption>()
    private var activeStorage: StorageOption? = null

    // ─── Init ─────────────────────────────────────────────────

    suspend fun init() = withContext(Dispatchers.IO) {
        scanAvailableStorage()
        selectBestStorage()
        Log.i(TAG, "Storage initialized: ${activeStorage?.label} (${activeStorage?.freeGb?.toInt()}GB free)")
    }

    // ─── Scan Available Storage ───────────────────────────────

    private fun scanAvailableStorage() {
        storageOptions.clear()

        // 1. Internal storage
        val internalDir = context.filesDir
        val internalStat = StatFs(internalDir.path)
        storageOptions.add(StorageOption(
            type    = StorageType.INTERNAL,
            label   = "Internal Storage",
            path    = "${internalDir.absolutePath}/recordings",
            totalGb = internalStat.totalBytes.toDouble() / 1e9,
            freeGb  = internalStat.availableBytes.toDouble() / 1e9,
        ))

        // 2. SD Card (if present)
        context.getExternalFilesDirs(null).forEachIndexed { i, dir ->
            if (dir != null && i > 0) {  // i=0 is internal, i>0 is external
                val stat = StatFs(dir.path)
                storageOptions.add(StorageOption(
                    type    = StorageType.SD_CARD,
                    label   = "SD Card",
                    path    = "${dir.absolutePath}/AnubisNVR",
                    totalGb = stat.totalBytes.toDouble() / 1e9,
                    freeGb  = stat.availableBytes.toDouble() / 1e9,
                ))
            }
        }

        // 3. SAF-picked folder (user chose via folder picker)
        config.safStorageUri?.let { uri ->
            val docFile = DocumentFile.fromTreeUri(context, Uri.parse(uri))
            if (docFile?.exists() == true) {
                storageOptions.add(StorageOption(
                    type    = StorageType.USB_OTG,
                    label   = "External Drive (USB/OTG)",
                    path    = uri,
                    uri     = Uri.parse(uri),
                    totalGb = 0.0,  // SAF doesn't provide free space easily
                    freeGb  = 999.0,
                ))
            }
        }

        Log.i(TAG, "Found ${storageOptions.size} storage options:")
        storageOptions.forEach { Log.i(TAG, "  ${it.label}: ${it.freeGb.toInt()}GB free") }
    }

    private fun selectBestStorage() {
        // Prefer: USB OTG > SD Card > Internal
        // But must have at least MIN_FREE_GB
        activeStorage = storageOptions
            .filter { it.freeGb >= MIN_FREE_GB }
            .maxByOrNull { it.freeGb }
            ?: storageOptions.firstOrNull()
    }

    // ─── Write Frame Data ─────────────────────────────────────

    suspend fun writeVideoData(cameraId: String, data: ByteArray) = withContext(Dispatchers.IO) {
        val storage = activeStorage ?: return@withContext

        // Check free space
        if (storage.freeGb < MIN_FREE_GB && storage.type != StorageType.USB_OTG) {
            Log.w(TAG, "Storage almost full! ${storage.freeGb}GB remaining")
            handleStorageFull()
            return@withContext
        }

        // Get or create segment writer for this camera
        val writer = activeSegments.getOrPut(cameraId) {
            createSegmentWriter(cameraId, storage)
        }

        // Check if segment needs rotation (every 30 minutes)
        if (writer.shouldRotate()) {
            sealSegment(cameraId)
            activeSegments[cameraId] = createSegmentWriter(cameraId, storage)
        }

        activeSegments[cameraId]?.write(data)
    }

    // ─── Segment Writer ───────────────────────────────────────

    private fun createSegmentWriter(cameraId: String, storage: StorageOption): SegmentWriter {
        val now       = System.currentTimeMillis()
        val dateStr   = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
        val timeStr   = SimpleDateFormat("HH-mm-ss", Locale.US).format(Date(now))
        val fileName  = "$timeStr.mp4"
        val dirPath   = "${storage.path}/$cameraId/$dateStr"

        return when {
            storage.uri != null -> SafSegmentWriter(context, storage.uri, cameraId, dateStr, fileName)
            else                -> FileSegmentWriter(dirPath, fileName)
        }
    }

    private suspend fun sealSegment(cameraId: String) = withContext(Dispatchers.IO) {
        val writer = activeSegments.remove(cameraId) ?: return@withContext
        val seg    = writer.seal()

        // Compute forensic hash
        val hash = computeHash(seg.filePath, seg.uri)

        val completed = seg.copy(sha256 = hash)
        completedSegments.add(completed)

        // Write to hash chain
        appendHashChain(cameraId, completed)

        Log.i(TAG, "Segment sealed: ${seg.filePath} (${seg.sizeBytes / 1024}KB) hash=${hash.take(16)}")
    }

    // ─── Snapshot ─────────────────────────────────────────────

    suspend fun saveSnapshot(cameraId: String, jpegData: ByteArray) = withContext(Dispatchers.IO) {
        val storage  = activeStorage ?: return@withContext
        val snapDir  = File("${storage.path}/snapshots")
        snapDir.mkdirs()
        val snapFile = File(snapDir, "$cameraId.jpg")
        snapFile.writeBytes(jpegData)
    }

    fun getSnapshotPath(cameraId: String): String? {
        val storage  = activeStorage ?: return null
        val snapFile = File("${storage.path}/snapshots/$cameraId.jpg")
        return if (snapFile.exists()) snapFile.absolutePath else null
    }

    // ─── Cloud Upload ─────────────────────────────────────────

    suspend fun uploadToCloud(segment: RecordingSegment) = withContext(Dispatchers.IO) {
        // Production: use Google Drive API, FTP, or S3
        // val driveService = Drive.Builder(...)
        // val file = com.google.api.services.drive.model.File()
        // driveService.files().create(file, content).execute()
        Log.d(TAG, "Cloud upload: ${segment.filePath}")
    }

    // ─── Storage Info ─────────────────────────────────────────

    fun getUsagePct(): Float {
        val storage = activeStorage ?: return 0f
        if (storage.totalGb <= 0) return 0f
        return ((storage.totalGb - storage.freeGb) / storage.totalGb * 100).toFloat()
    }

    fun getAvailableOptions()  = storageOptions.toList()
    fun getActiveStorage()     = activeStorage
    fun getCompletedSegments() = completedSegments.toList()

    // ─── Retention / Cleanup ──────────────────────────────────

    suspend fun runRetentionCleanup(retentionDays: Int) = withContext(Dispatchers.IO) {
        val cutoff     = System.currentTimeMillis() - retentionDays * 86_400_000L
        val storage    = activeStorage ?: return@withContext
        val recordsDir = File(storage.path)
        if (!recordsDir.exists()) return@withContext

        var deletedCount = 0
        var deletedBytes = 0L

        recordsDir.walkTopDown()
            .filter { it.isFile && it.lastModified() < cutoff && it.name.endsWith(".mp4") }
            .forEach { file ->
                deletedBytes += file.length()
                file.delete()
                deletedCount++
            }

        if (deletedCount > 0) {
            Log.i(TAG, "Retention cleanup: deleted $deletedCount files (${deletedBytes / 1_048_576}MB)")
        }
    }

    private fun handleStorageFull() {
        // Delete oldest recordings to make space
        val storage = activeStorage ?: return
        val files = File(storage.path).walkTopDown()
            .filter { it.isFile && it.name.endsWith(".mp4") }
            .sortedBy { it.lastModified() }
            .toList()

        files.take(files.size / 10).forEach { it.delete() }  // Delete oldest 10%
    }

    suspend fun flushAll() = withContext(Dispatchers.IO) {
        activeSegments.keys.toList().forEach { sealSegment(it) }
    }

    // ─── Forensic Hash ────────────────────────────────────────

    private fun computeHash(path: String, uri: Uri?): String {
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            val stream = if (uri != null) {
                context.contentResolver.openInputStream(uri)
            } else {
                FileInputStream(path)
            } ?: return "HASH_ERROR"

            val buf = ByteArray(65536)
            stream.use { inp ->
                var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    digest.update(buf, 0, n)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Hash computation failed: ${e.message}")
            return "HASH_ERROR"
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun appendHashChain(cameraId: String, seg: RecordingSegment) {
        val storage  = activeStorage ?: return
        val chainDir = File("${storage.path}/$cameraId")
        chainDir.mkdirs()
        val chainFile = File(chainDir, "hashchain.jsonl")
        chainFile.appendText(
            """{"file":"${seg.filePath}","sha256":"${seg.sha256}","size":${seg.sizeBytes},"ts":${seg.endTime}}""" + "\n"
        )
    }
}

// ─── Segment Writer interfaces ────────────────────────────────

abstract class SegmentWriter {
    protected var startTime  = System.currentTimeMillis()
    protected var bytesWritten = 0L
    protected var frameCount = 0

    fun shouldRotate(): Boolean {
        val ageMinutes = (System.currentTimeMillis() - startTime) / 60_000
        return ageMinutes >= StorageManager.SEGMENT_MINUTES
    }

    abstract fun write(data: ByteArray)
    abstract fun seal(): RecordingSegment
}

// File-based writer (Internal + SD Card)
class FileSegmentWriter(dirPath: String, fileName: String) : SegmentWriter() {
    private val file: File
    private val stream: OutputStream

    init {
        File(dirPath).mkdirs()
        file   = File(dirPath, fileName)
        stream = FileOutputStream(file)
    }

    override fun write(data: ByteArray) {
        stream.write(data)
        bytesWritten += data.size
        frameCount++
    }

    override fun seal(): RecordingSegment {
        stream.flush()
        stream.close()
        return RecordingSegment(
            cameraId   = file.parentFile?.parentFile?.name ?: "unknown",
            filePath   = file.absolutePath,
            uri        = null,
            startTime  = startTime,
            endTime    = System.currentTimeMillis(),
            sizeBytes  = bytesWritten,
            sha256     = "",
            frameCount = frameCount,
        )
    }
}

// SAF-based writer (USB OTG / custom folder)
class SafSegmentWriter(
    private val context:   Context,
    private val treeUri:   Uri,
    private val cameraId:  String,
    private val dateStr:   String,
    private val fileName:  String,
) : SegmentWriter() {
    private var fileUri: Uri? = null
    private var stream:  OutputStream? = null

    init {
        val treeDoc = DocumentFile.fromTreeUri(context, treeUri)
        val camDir  = treeDoc?.findFile(cameraId) ?: treeDoc?.createDirectory(cameraId)
        val dateDir = camDir?.findFile(dateStr)   ?: camDir?.createDirectory(dateStr)
        val file    = dateDir?.createFile("video/mp4", fileName)
        fileUri = file?.uri
        stream  = fileUri?.let { context.contentResolver.openOutputStream(it) }
    }

    override fun write(data: ByteArray) {
        stream?.write(data)
        bytesWritten += data.size
        frameCount++
    }

    override fun seal(): RecordingSegment {
        stream?.flush()
        stream?.close()
        return RecordingSegment(
            cameraId   = cameraId,
            filePath   = fileUri.toString(),
            uri        = fileUri,
            startTime  = startTime,
            endTime    = System.currentTimeMillis(),
            sizeBytes  = bytesWritten,
            sha256     = "",
            frameCount = frameCount,
        )
    }
}

private const val SEGMENT_MINUTES = 30
